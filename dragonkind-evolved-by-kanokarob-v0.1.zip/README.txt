Dragonkind Evolved is brought to you by kanokarob

Installation Instructions
=========================
Create a new world, open the Data Packs folder via the Create World screen, and paste this .zip file in that folder. Cheats *do not need* to be turned on.

Uninstall instructions
=========================
Before removing Dragonkind Evolved from your world, use "/function dke:uninstall" to clean up excess entities. End Crystals and the Ender Dragon will remain and return to their vanilla behavior. Any Dragon Breath clouds will also remain, even if custom. Custom items will not be taken from players, but will lose most functionality not covered by Attributes or Enchantments.