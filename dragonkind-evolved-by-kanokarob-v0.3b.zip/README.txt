Dragonkind Evolved is brought to you by kanokarob

Installation Instructions
=========================
Create a new world, open the Data Packs folder via the Create World screen, and paste this .zip file in that folder. Cheats *do not need* to be turned on.

Commands
=========================
You can use the following command structure to either change the current dragon type, or set what the next dragon type will be, depending on who you execute it as.

Use "/function dke:dragons/set_XXXXX" where XXXXX is the type of dragon you want, to make the next dragon that spawns that type.

Use "/execute as @e[type=ender_dragon,tag=dke.started] run function dke:dragons/set_XXXXX" where XXXXX is the type of dragon you want, to make the current dragon that type.


Uninstall instructions
=========================
Before removing Dragonkind Evolved from your world, use "/function dke:uninstall" to clean up excess entities. End Crystals and the Ender Dragon will remain and return to their vanilla behavior. Any Dragon Breath clouds will also remain, even if custom. Custom items will not be taken from players, but will lose most functionality not covered by Attributes or Enchantments.